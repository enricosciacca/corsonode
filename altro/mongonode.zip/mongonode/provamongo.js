

const mongojs = require('mongojs');
const db = mongojs('localhost/prova', ["aziende2"])


let azienda1 = {
    nome: "PCM",
    descrizione: "Dove faccio il corso",
    ha_reparti: false
}

let azienda2 = {
    nome: "ACME",
    descrizione: "Producono tutto",
    ha_reparti: true,
    reparti: [ "elettronica", "edilizia", "pasticceria" ]
}

// $gt $lt $gte $gle

db.aziende2.insert( azienda1, (err, data) => {
    if (err) return console.error(err)
    console.log("HO INSERITO:", data);

    db.aziende2.insert(azienda2, (err, data2) => {
        if (err) return console.error(err)
        console.log("HO INSERITO:", data2);

        let id_azienda2 = data2._id

        db.aziende2.update( { _id:  id_azienda2 },
                    {$set: {descrizione: "Producono QUASI tutto" }},
                                (err, data3) => {
            if (err) return console.error(err)

            db.aziende2.findOne( { _id:  id_azienda2 }, (err, data4) => {
                console.log("GET ONE: ", data4)

                db.close( ()=> console.log("FINE")  )
            } )
        })
    })
})
